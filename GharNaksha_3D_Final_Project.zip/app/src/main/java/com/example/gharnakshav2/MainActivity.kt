package com.example.gharnakshav2

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

data class Room(
    val id: Int, val name: String,
    val x: Float, val y: Float, val w: Float, val h: Float,
    val floor: Int = 0
)

private val Green = Color(0xFF39FF14)
private val DarkGreen = Color(0xFF087A00)
private val Page = Color(0xFFF4FFF2)

@Composable
fun GharNaksha3D() {
    var tab by remember { mutableIntStateOf(0) }
    var width by remember { mutableStateOf("30") }
    var length by remember { mutableStateOf("40") }
    var mode by remember { mutableStateOf("3D") }
    var floor by remember { mutableIntStateOf(0) }
    var nextId by remember { mutableIntStateOf(7) }
    var rotation by remember { mutableFloatStateOf(0f) }
    var scale by remember { mutableFloatStateOf(1f) }
    var saved by remember { mutableStateOf(false) }
    var rooms by remember {
        mutableStateOf(
            listOf(
                Room(1, "Living Room", 0f, 0f, .55f, .38f),
                Room(2, "Kitchen", .55f, 0f, .45f, .38f),
                Room(3, "Bedroom 1", 0f, .38f, .50f, .42f),
                Room(4, "Bedroom 2", .50f, .38f, .50f, .42f),
                Room(5, "Bathroom", .50f, .80f, .25f, .20f),
                Room(6, "Staircase", .75f, .80f, .25f, .20f)
            )
        )
    }

    fun addRoom(name: String = "New Room") {
        val id = nextId++
        rooms = rooms + Room(id, name, .12f, .12f, .32f, .24f, floor)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green, onPrimary = Color(0xFF063B00),
            secondary = DarkGreen, background = Page, surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Page,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf(
                        "Home" to Icons.Default.Home,
                        "My Designs" to Icons.Default.Folder,
                        "3D" to Icons.Default.ViewInAr,
                        "Settings" to Icons.Default.Settings
                    ).forEachIndexed { i, pair ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(pair.second, contentDescription = pair.first) },
                            label = { Text(pair.first) }
                        )
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> HomeScreen(
                    pad, width, length, { width = it }, { length = it },
                    mode, { mode = it }, floor, { floor = it },
                    saved, { saved = true }, { addRoom() }, rooms.size
                )
                1 -> DesignsScreen(pad, saved)
                2 -> PlanScreen(
                    pad, width, length, mode, { mode = it }, floor, { floor = it },
                    rotation, { rotation = it }, scale, { scale = it }, rooms
                )
                else -> SettingsScreen(pad)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    pad: PaddingValues, width: String, length: String,
    setWidth: (String) -> Unit, setLength: (String) -> Unit,
    mode: String, setMode: (String) -> Unit,
    floor: Int, setFloor: (Int) -> Unit,
    saved: Boolean, save: () -> Unit, addRoom: () -> Unit, roomCount: Int
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("🏠 GharNaksha 3D", style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold, color = DarkGreen)
            Text("Apna Ghar, Apni Soch, 3D Mein.", color = DarkGreen,
                fontWeight = FontWeight.SemiBold)
        }
        item {
            Button(
                onClick = addRoom, modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(Green, Color(0xFF063B00))
            ) { Text("+  New Naksha", fontWeight = FontWeight.Bold) }
        }
        item {
            OutlinedButton(
                onClick = {}, modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Icon(Icons.Default.Folder, null); Spacer(Modifier.width(8.dp)); Text("My Designs") }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Plot Size", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(width, setWidth, { Text("Width (ft)") },
                            Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(length, setLength, { Text("Length (ft)") },
                            Modifier.weight(1f), singleLine = true)
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Quick Start", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickButton("2D Plan") { setMode("2D") }
                        QuickButton("3D View") { setMode("3D") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickButton("Rooms") { addRoom() }
                        QuickButton("Kitchen") { addRoom() }
                        QuickButton("Bathroom") { addRoom() }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(floor == 0, { setFloor(0) }, { Text("Ground Floor") })
                        FilterChip(floor == 1, { setFloor(1) }, { Text("First Floor") })
                    }
                }
            }
        }
        item {
            Button(
                onClick = save, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(DarkGreen)
            ) { Text(if (saved) "Saved ✓" else "Save Project") }
        }
        item {
            Text("Current: $width × $length ft • ${if (floor == 0) "Ground" else "First"} Floor • $roomCount rooms",
                style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun QuickButton(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick, Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
        Text(label)
    }
}

@Composable
private fun DesignsScreen(pad: PaddingValues, saved: Boolean) {
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
        Text("My Designs", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (!saved) {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("No saved designs yet.", fontWeight = FontWeight.Bold)
                    Text("Home screen se Save Project dabao.")
                }
            }
        } else {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("My Dream House", fontWeight = FontWeight.Bold)
                    Text("30 × 40 ft • 2 Floors", color = Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    Text("Saved project", color = DarkGreen)
                }
            }
        }
    }
}

@Composable
private fun PlanScreen(
    pad: PaddingValues, width: String, length: String, mode: String, setMode: (String) -> Unit,
    floor: Int, setFloor: (Int) -> Unit, rotation: Float, setRotation: (Float) -> Unit,
    scale: Float, setScale: (Float) -> Unit, rooms: List<Room>
) {
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(mode == "2D", { setMode("2D") }, { Text("2D Plan") })
            FilterChip(mode == "3D", { setMode("3D") }, { Text("3D View") })
            FilterChip(floor == 0, { setFloor(0) }, { Text("Ground") })
            FilterChip(floor == 1, { setFloor(1) }, { Text("First") })
        }
        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxSize(), RoundedCornerShape(18.dp)) {
            Canvas(
                Modifier.fillMaxSize().padding(8.dp).pointerInput(mode) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        setScale((scale * zoom).coerceIn(.7f, 2.2f))
                        if (mode == "3D") setRotation((rotation + pan.x * .35f) % 360f)
                    }
                }
            ) {
                val ox = 35f
                val oy = 35f
                val pw = size.width - 70f
                val ph = size.height - 70f
                if (mode == "2D") {
                    drawRect(Color.White, Offset(ox, oy), Size(pw, ph))
                    drawRect(DarkGreen, Offset(ox, oy), Size(pw, ph), style = Stroke(5f))
                    rooms.filter { it.floor == floor || it.floor == 0 }.forEach { r ->
                        val x = ox + r.x * pw * scale
                        val y = oy + r.y * ph * scale
                        val w = r.w * pw * scale
                        val h = r.h * ph * scale
                        drawRect(Color(0xFFE8F6E5), Offset(x, y), Size(w, h))
                        drawRect(Color.DarkGray, Offset(x, y), Size(w, h), style = Stroke(3f))
                        drawContext.canvas.nativeCanvas.drawText(
                            r.name, x + 7, y + h / 2,
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.DKGRAY
                                textSize = 22f
                            }
                        )
                    }
                } else {
                    val a = Math.toRadians(rotation.toDouble())
                    val c = cos(a).toFloat()
                    val s = sin(a).toFloat()
                    fun p(x: Float, y: Float, z: Float): Offset {
                        val xx = x * c - z * s
                        val zz = x * s + z * c
                        return Offset(
                            ox + pw * (.08f + xx * .78f * scale),
                            oy + ph * (.82f - y * .56f * scale - zz * .28f * scale)
                        )
                    }
                    fun poly(vararg a: Offset) = Path().apply {
                        moveTo(a[0].x, a[0].y)
                        for (i in 1 until a.size) lineTo(a[i].x, a[i].y)
                        close()
                    }
                    val q = arrayOf(
                        p(0f,0f,0f), p(1f,0f,0f), p(1f,1f,0f), p(0f,1f,0f),
                        p(0f,0f,.62f), p(1f,0f,.62f), p(1f,1f,.62f), p(0f,1f,.62f)
                    )
                    val front = poly(q[0],q[1],q[2],q[3])
                    val side = poly(q[1],q[5],q[6],q[2])
                    val roof = poly(q[3],q[7],q[6],q[2])
                    drawPath(front, Color(0xFFE8F2FA))
                    drawPath(side, Color(0xFFD5E4F0))
                    drawPath(roof, Color(0xFFC6D8E6))
                    listOf(front,side,roof).forEach { drawPath(it, Color.DarkGray, style=Stroke(4f)) }
                    drawContext.canvas.nativeCanvas.drawText(
                        "Drag = Rotate • Pinch = Zoom",
                        ox + pw * .18f, oy + ph * .95f,
                        android.graphics.Paint().apply {
                            color = android.graphics.Color.DKGRAY; textSize = 24f
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(pad: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        listOf(
            "Save / Load Project",
            "Export 3D Image",
            "Export Floor Plan (PDF)",
            "Theme",
            "Language",
            "Help & Support",
            "About App"
        ).forEach { label ->
            Card(shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(label, Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Card(shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(DarkGreen)) {
            Column(Modifier.padding(18.dp)) {
                Text("GharNaksha 3D Pro", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Advanced tools • HD export • No ads", color = Color.White)
                Spacer(Modifier.height(8.dp))
                Button(onClick = {}, colors = ButtonDefaults.buttonColors(Green, Color(0xFF063B00))) {
                    Text("Upgrade")
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GharNaksha3D() }
    }
}
